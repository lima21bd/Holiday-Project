## say goodbye
* goodbye
  - utter_goodbye

## ask for time zone long
* greet
  - utter_greet
* find_time_zone
  - utter_ask_location
* city_info
  - utter_finding_time_zone
  - action_find_and_show_time_zone
* thanks
  - utter_you_are_welcome
  - utter_goodbye

## ask for time zone short
* greet
  - utter_greet
* find_time_zone_for_location
  - utter_finding_time_zone
  - action_find_and_show_time_zone
* thanks
  - utter_you_are_welcome
  - utter_goodbye
